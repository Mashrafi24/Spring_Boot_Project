CALCSPACE — ALL-IN-ONE CALCULATOR WEBSITE

প্রজেক্টে রয়েছে:
- 30+ calculators
- Math & Everyday, Health & Fitness, Finance, Date & Time, Student, Fun & Lifestyle categories
- Search এবং category filter
- Responsive modern colorful interface
- Spring Boot backend এবং /api/health endpoint

IntelliJ IDEA-তে চালানোর নিয়ম:
1. ZIP ফাইলটি Extract করুন।
2. IntelliJ IDEA খুলুন: File > Open।
3. Extract করা AllInOneCalculator folder নির্বাচন করুন।
4. Maven project import এবং dependency download শেষ হওয়া পর্যন্ত অপেক্ষা করুন।
5. src/main/java/com/mashrafi/calculator/AllInOneCalculatorApplication.java খুলুন।
6. main() method-এর পাশে সবুজ Run বাটনে ক্লিক করুন।
7. Console-এ Started AllInOneCalculatorApplication দেখলে browser-এ যান:
   http://localhost:8080/

Backend check:
http://localhost:8080/api/health

প্রয়োজন:
- JDK 25 (IntelliJ Project SDK এবং Maven Runner JDK হিসেবে নির্বাচন করুন)
- প্রথমবার Maven dependency download করার জন্য Internet

গুরুত্বপূর্ণ:
- Spring Boot Embedded Tomcat ব্যবহার করে; আলাদা Tomcat 11 configure করার প্রয়োজন নেই।
- Port 8080 ব্যস্ত থাকলে src/main/resources/application.properties-এ
  server.port=8081 করে দিন, তারপর http://localhost:8081/ খুলুন।
- Health, BMI, calorie, hydration, stress ও fun calculator-এর ফলাফল সাধারণ estimate বা self-reflection;
  এগুলো চিকিৎসা/রোগ নির্ণয় বা পেশাদার পরামর্শ নয়।
- Love/Friendship score শুধু বিনোদনের জন্য।
