package com.mashrafi.calculator;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

@RestController
public class HomeController {
    @GetMapping("/api/health")
    public Map<String, String> health() {
        return Map.of(
            "application", "All-in-One Calculator",
            "status", "running",
            "message", "Spring Boot is working!"
        );
    }
}
