package com.mashrafi.calculator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AllInOneCalculatorApplication {
    public static void main(String[] args) {
        SpringApplication.run(AllInOneCalculatorApplication.class, args);
    }
}
